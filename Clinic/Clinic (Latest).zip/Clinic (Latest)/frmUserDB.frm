VERSION 5.00
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmUserDB 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   7050
   ClientLeft      =   15
   ClientTop       =   15
   ClientWidth     =   15825
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7050
   ScaleWidth      =   15825
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame fraMain 
      BackColor       =   &H80000000&
      Height          =   7215
      Left            =   2520
      TabIndex        =   29
      Top             =   -120
      Width           =   13335
      Begin VB.Frame fraPrescription 
         BackColor       =   &H00C0C0C0&
         Height          =   7335
         Left            =   0
         TabIndex        =   52
         Top             =   0
         Width           =   13335
         Begin VB.TextBox txtGivenMed 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   435
            Left            =   2880
            MaxLength       =   4
            TabIndex        =   63
            Top             =   2160
            Width           =   1695
         End
         Begin VB.TextBox txtPID 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   435
            Left            =   2880
            MaxLength       =   4
            TabIndex        =   13
            Top             =   960
            Width           =   1695
         End
         Begin VB.TextBox txtDiagnosis 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   3255
            Left            =   240
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   15
            Top             =   3840
            Width           =   6255
         End
         Begin VB.TextBox txtTreatment 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   15
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   3255
            Left            =   6840
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   16
            Top             =   3840
            Width           =   6255
         End
         Begin VB.CommandButton cmdPConfirm 
            Caption         =   "Confirm"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   4680
            TabIndex        =   17
            Top             =   960
            Width           =   1095
         End
         Begin VB.CommandButton cmdPEdit 
            Caption         =   "Edit Medication"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   11400
            TabIndex        =   18
            Top             =   960
            Width           =   1695
         End
         Begin VB.CommandButton cmdInv 
            Caption         =   "Check Inventory"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   11400
            TabIndex        =   19
            Top             =   1800
            Width           =   1695
         End
         Begin VB.ComboBox cboMedicine 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   405
            Left            =   2880
            Style           =   2  'Dropdown List
            TabIndex        =   14
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdMedRefresh 
            Caption         =   "Refresh"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   4680
            TabIndex        =   53
            Top             =   1560
            Width           =   1095
         End
         Begin VB.Label lblSelectedSymptom 
            BackColor       =   &H00C0C0C0&
            Caption         =   "Patient Symptom: None"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00000080&
            Height          =   855
            Left            =   6120
            TabIndex        =   64
            Top             =   2280
            Width           =   5055
         End
         Begin VB.Shape Shape4 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   495
            Left            =   6000
            Top             =   3240
            Width           =   1455
         End
         Begin VB.Label Label3 
            Alignment       =   2  'Center
            BackColor       =   &H00800000&
            Caption         =   "Medicine Details"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   0
            TabIndex        =   60
            Top             =   240
            Width           =   3735
         End
         Begin VB.Label lblPID 
            BackStyle       =   0  'Transparent
            Caption         =   "Select Patient ID:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   240
            TabIndex        =   59
            Top             =   1080
            Width           =   2535
         End
         Begin VB.Label lblDiagnosis 
            Alignment       =   2  'Center
            BackColor       =   &H0000C000&
            Caption         =   "Diagnosis"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   240
            TabIndex        =   58
            Top             =   3240
            Width           =   6255
         End
         Begin VB.Label lblTreatment 
            Alignment       =   2  'Center
            BackColor       =   &H0000C000&
            Caption         =   "Treatment"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   6840
            TabIndex        =   57
            Top             =   3240
            Width           =   6255
         End
         Begin VB.Label lblMedicineG 
            BackStyle       =   0  'Transparent
            Caption         =   "Medicine Given:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   240
            TabIndex        =   56
            Top             =   2280
            Width           =   2535
         End
         Begin VB.Label lblMedicine 
            BackStyle       =   0  'Transparent
            Caption         =   "Select Medicine:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   240
            TabIndex        =   55
            Top             =   1680
            Width           =   2655
         End
         Begin VB.Label lblSelectedID 
            BackColor       =   &H00C0C0C0&
            Caption         =   "Selected ID: None"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00000080&
            Height          =   1095
            Left            =   6120
            TabIndex        =   54
            Top             =   1080
            Width           =   5055
         End
         Begin VB.Shape Shape6 
            BackColor       =   &H00800000&
            BorderColor     =   &H00800000&
            FillColor       =   &H00800000&
            FillStyle       =   0  'Solid
            Height          =   735
            Left            =   0
            Top             =   120
            Width           =   13335
         End
      End
      Begin VB.Frame fraRemovePatient 
         BackColor       =   &H00C0C0C0&
         Height          =   7335
         Left            =   0
         TabIndex        =   43
         Top             =   0
         Width           =   13335
         Begin VB.CommandButton cmdRConfirm 
            Caption         =   "Confirm"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   3480
            TabIndex        =   24
            Top             =   960
            Width           =   1215
         End
         Begin VB.TextBox txtRID 
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   1800
            MaxLength       =   4
            TabIndex        =   23
            Top             =   960
            Width           =   1575
         End
         Begin VB.CommandButton cmdRefreshArchive 
            Caption         =   "Refresh"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   1920
            TabIndex        =   26
            Top             =   1560
            Width           =   1455
         End
         Begin VB.CommandButton cmdLoadArchive 
            Caption         =   "Load Archive"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   240
            TabIndex        =   25
            Top             =   1560
            Width           =   1575
         End
         Begin MSDataGridLib.DataGrid DGArchive 
            Height          =   4215
            Left            =   240
            TabIndex        =   44
            Top             =   2880
            Width           =   12855
            _ExtentX        =   22675
            _ExtentY        =   7435
            _Version        =   393216
            HeadLines       =   1
            RowHeight       =   15
            BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ColumnCount     =   2
            BeginProperty Column00 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column01 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            SplitCount      =   1
            BeginProperty Split0 
               BeginProperty Column00 
               EndProperty
               BeginProperty Column01 
               EndProperty
            EndProperty
         End
         Begin VB.Shape Shape16 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   495
            Left            =   5400
            Top             =   2280
            Width           =   7695
         End
         Begin VB.Shape Shape15 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   495
            Left            =   4800
            Top             =   2280
            Width           =   375
         End
         Begin VB.Label Label2 
            Alignment       =   2  'Center
            BackColor       =   &H00800000&
            Caption         =   "Archive Patient Data"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   0
            TabIndex        =   48
            Top             =   240
            Width           =   4455
         End
         Begin VB.Label lblRID 
            BackStyle       =   0  'Transparent
            Caption         =   "Select ID:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   240
            TabIndex        =   47
            Top             =   1080
            Width           =   1575
         End
         Begin VB.Label Label1 
            Alignment       =   2  'Center
            BackColor       =   &H0000C000&
            Caption         =   "Patient Archive Logs"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   240
            TabIndex        =   46
            Top             =   2280
            Width           =   4335
         End
         Begin VB.Label lblSelectedPatientRID 
            BackColor       =   &H00C0C0C0&
            Caption         =   "Selected Patient: None"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   15.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00000080&
            Height          =   495
            Left            =   3600
            TabIndex        =   45
            Top             =   1680
            Width           =   7095
         End
         Begin VB.Shape Shape7 
            BackColor       =   &H00800000&
            BorderColor     =   &H00800000&
            FillColor       =   &H00800000&
            FillStyle       =   0  'Solid
            Height          =   735
            Left            =   0
            Top             =   120
            Width           =   13335
         End
      End
      Begin VB.Frame fraAddPatient 
         BackColor       =   &H00C0C0C0&
         Height          =   7335
         Left            =   0
         TabIndex        =   30
         Top             =   0
         Width           =   13335
         Begin VB.ComboBox txtSymptom 
            Height          =   315
            ItemData        =   "frmUserDB.frx":0000
            Left            =   10560
            List            =   "frmUserDB.frx":0002
            TabIndex        =   72
            Text            =   "txtSymptom"
            Top             =   1800
            Width           =   1935
         End
         Begin VB.ComboBox cboSex 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   465
            Left            =   10560
            Style           =   2  'Dropdown List
            TabIndex        =   8
            Top             =   1080
            Width           =   1935
         End
         Begin VB.TextBox txtAge 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   6720
            Locked          =   -1  'True
            TabIndex        =   42
            Top             =   1800
            Width           =   1935
         End
         Begin VB.CommandButton cmdAddConfirm 
            Caption         =   "Confirm"
            Default         =   -1  'True
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   11760
            TabIndex        =   12
            Top             =   3360
            Width           =   1335
         End
         Begin VB.TextBox txtContact 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   10560
            MaxLength       =   11
            TabIndex        =   10
            Top             =   2520
            Width           =   2535
         End
         Begin VB.TextBox txtComplain 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   3015
            Left            =   240
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   11
            Top             =   4080
            Width           =   12855
         End
         Begin VB.TextBox txtAddress 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   1560
            TabIndex        =   9
            Top             =   2520
            Width           =   7095
         End
         Begin VB.TextBox txtName 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   1560
            TabIndex        =   6
            Top             =   1800
            Width           =   3495
         End
         Begin VB.TextBox txtID 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   1560
            Locked          =   -1  'True
            TabIndex        =   33
            Top             =   1080
            Width           =   975
         End
         Begin VB.CommandButton cmdAddSymptom 
            Caption         =   "Add New Symptom"
            Height          =   255
            Left            =   11520
            TabIndex        =   73
            Top             =   1800
            Width           =   615
         End
         Begin MSComCtl2.DTPicker dtpDOB 
            Height          =   495
            Left            =   6720
            TabIndex        =   7
            TabStop         =   0   'False
            Top             =   1080
            Width           =   1935
            _ExtentX        =   3413
            _ExtentY        =   873
            _Version        =   393216
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            CustomFormat    =   """MM/dd/yyyy"""
            Format          =   133627907
            CurrentDate     =   46073
         End
         Begin VB.TextBox txtDOB 
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   360
            Left            =   6960
            Locked          =   -1  'True
            TabIndex        =   28
            Text            =   "Don't Remove, Put under Date Dropdown"
            Top             =   1080
            Width           =   1455
         End
         Begin VB.Shape Shape11 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   615
            Left            =   10920
            Top             =   3360
            Width           =   2055
         End
         Begin VB.Shape Shape10 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   615
            Left            =   10320
            Top             =   3360
            Width           =   375
         End
         Begin VB.Label lblContact 
            BackStyle       =   0  'Transparent
            Caption         =   "Contact:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   9000
            TabIndex        =   41
            Top             =   2520
            Width           =   1575
         End
         Begin VB.Label lblComplain 
            Alignment       =   2  'Center
            BackColor       =   &H0000C000&
            Caption         =   "Patient Explanation"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   240
            TabIndex        =   40
            Top             =   3480
            Width           =   3855
         End
         Begin VB.Label lblSymptom 
            BackStyle       =   0  'Transparent
            Caption         =   "Symptom:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   9000
            TabIndex        =   39
            Top             =   1800
            Width           =   1575
         End
         Begin VB.Label lblSex 
            BackStyle       =   0  'Transparent
            Caption         =   "Sex:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   9000
            TabIndex        =   38
            Top             =   1200
            Width           =   1215
         End
         Begin VB.Label lblAddress 
            BackStyle       =   0  'Transparent
            Caption         =   "Address:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   240
            TabIndex        =   37
            Top             =   2640
            Width           =   1455
         End
         Begin VB.Label lblDOB 
            BackStyle       =   0  'Transparent
            Caption         =   "BirthDate:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   5160
            TabIndex        =   36
            Top             =   1200
            Width           =   1575
         End
         Begin VB.Label lblAge 
            BackStyle       =   0  'Transparent
            Caption         =   "Age:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   5160
            TabIndex        =   35
            Top             =   1800
            Width           =   1215
         End
         Begin VB.Label lblName 
            BackStyle       =   0  'Transparent
            Caption         =   "Name:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   240
            TabIndex        =   34
            Top             =   1920
            Width           =   1215
         End
         Begin VB.Label lblID 
            BackStyle       =   0  'Transparent
            Caption         =   "ID:"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   14.25
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   240
            TabIndex        =   32
            Top             =   1200
            Width           =   1215
         End
         Begin VB.Label lblAddPatient 
            Alignment       =   2  'Center
            BackColor       =   &H00800000&
            Caption         =   "Add Patient Details"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   0
            TabIndex        =   31
            Top             =   240
            Width           =   4215
         End
         Begin VB.Shape Shape8 
            BackColor       =   &H00800000&
            BorderColor     =   &H00800000&
            FillColor       =   &H00800000&
            FillStyle       =   0  'Solid
            Height          =   735
            Left            =   0
            Top             =   120
            Width           =   13335
         End
         Begin VB.Shape Shape9 
            BackColor       =   &H0000C000&
            BorderColor     =   &H0000C000&
            FillColor       =   &H0000C000&
            FillStyle       =   0  'Solid
            Height          =   615
            Left            =   240
            Top             =   3360
            Width           =   9855
         End
      End
      Begin VB.Frame Frame1 
         BackColor       =   &H00C0C0C0&
         Height          =   7215
         Left            =   0
         TabIndex        =   65
         Top             =   0
         Visible         =   0   'False
         Width           =   13335
         Begin VB.CommandButton cmdLog 
            Caption         =   "Consultation Log"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   120
            TabIndex        =   70
            Top             =   1080
            Width           =   1455
         End
         Begin VB.CommandButton cmdInventory 
            Caption         =   "Full Inventory"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   1680
            TabIndex        =   69
            Top             =   1080
            Width           =   1455
         End
         Begin VB.CommandButton cmdLowStock 
            Caption         =   "Low Stocks"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   3240
            TabIndex        =   68
            Top             =   1080
            Width           =   1455
         End
         Begin VB.CommandButton cmdMedicalCert 
            Caption         =   "Generate"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   4800
            TabIndex        =   67
            ToolTipText     =   "Generate Medical Certificate"
            Top             =   1080
            Width           =   1455
         End
         Begin VB.CommandButton cmdPrint 
            Caption         =   "Print Log"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   6360
            TabIndex        =   66
            Top             =   1080
            Width           =   1455
         End
         Begin MSDataGridLib.DataGrid DGReport 
            Height          =   5055
            Left            =   120
            TabIndex        =   71
            Top             =   1920
            Width           =   12975
            _ExtentX        =   22886
            _ExtentY        =   8916
            _Version        =   393216
            HeadLines       =   1
            RowHeight       =   15
            BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ColumnCount     =   2
            BeginProperty Column00 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column01 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            SplitCount      =   1
            BeginProperty Split0 
               BeginProperty Column00 
               EndProperty
               BeginProperty Column01 
               EndProperty
            EndProperty
         End
         Begin VB.Shape Shape14 
            BackColor       =   &H00800000&
            BorderColor     =   &H00800000&
            FillColor       =   &H00800000&
            FillStyle       =   0  'Solid
            Height          =   735
            Left            =   0
            Top             =   120
            Width           =   13335
         End
      End
      Begin VB.Frame fraPatientLog 
         BackColor       =   &H00C0C0C0&
         Height          =   7335
         Left            =   0
         TabIndex        =   49
         Top             =   0
         Width           =   13335
         Begin VB.CommandButton Command9 
            Caption         =   "&Search"
            Height          =   495
            Left            =   3840
            TabIndex        =   62
            Top             =   1680
            Width           =   855
         End
         Begin VB.TextBox Text5 
            Appearance      =   0  'Flat
            Height          =   495
            Left            =   240
            MaxLength       =   4
            TabIndex        =   61
            Top             =   1680
            Width           =   3375
         End
         Begin VB.CommandButton cmdEdit 
            Caption         =   "Edit Data"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   3360
            TabIndex        =   20
            Top             =   960
            Width           =   1335
         End
         Begin VB.CommandButton cmdLoad 
            Caption         =   "Load Data"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   240
            TabIndex        =   21
            Top             =   960
            Width           =   1455
         End
         Begin VB.CommandButton cmdRefresh 
            Caption         =   "Refresh"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   12
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   615
            Left            =   1800
            TabIndex        =   22
            Top             =   960
            Width           =   1455
         End
         Begin MSDataGridLib.DataGrid DGData 
            Height          =   4695
            Left            =   240
            TabIndex        =   50
            Top             =   2280
            Width           =   12855
            _ExtentX        =   22675
            _ExtentY        =   8281
            _Version        =   393216
            BackColor       =   14737632
            HeadLines       =   1
            RowHeight       =   15
            BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "Tahoma"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ColumnCount     =   2
            BeginProperty Column00 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column01 
               DataField       =   ""
               Caption         =   ""
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            SplitCount      =   1
            BeginProperty Split0 
               BeginProperty Column00 
               EndProperty
               BeginProperty Column01 
               EndProperty
            EndProperty
         End
         Begin VB.Label lblLogs 
            Alignment       =   2  'Center
            BackColor       =   &H00800000&
            Caption         =   "Patient Data Logs"
            BeginProperty Font 
               Name            =   "Tahoma"
               Size            =   18
               Charset         =   0
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00FFFFFF&
            Height          =   495
            Left            =   0
            TabIndex        =   51
            Top             =   240
            Width           =   3975
         End
         Begin VB.Shape Shape3 
            BackColor       =   &H00800000&
            BorderColor     =   &H00800000&
            FillColor       =   &H00800000&
            FillStyle       =   0  'Solid
            Height          =   735
            Left            =   0
            Top             =   120
            Width           =   13335
         End
      End
      Begin VB.Shape Shape13 
         BackColor       =   &H00800000&
         BorderColor     =   &H00800000&
         FillColor       =   &H00800000&
         FillStyle       =   0  'Solid
         Height          =   735
         Left            =   0
         Top             =   120
         Width           =   13335
      End
   End
   Begin VB.Frame fraUserControlPanel 
      Height          =   7215
      Left            =   0
      TabIndex        =   27
      Top             =   -120
      Width           =   2535
      Begin VB.CommandButton cmdReport 
         Appearance      =   0  'Flat
         Caption         =   "Create Clinic Report"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   960
         Style           =   1  'Graphical
         TabIndex        =   5
         Top             =   6120
         Width           =   1575
      End
      Begin VB.CommandButton cmdPatientLog 
         Caption         =   "View Patient Log"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   960
         Style           =   1  'Graphical
         TabIndex        =   3
         Top             =   4440
         Width           =   1575
      End
      Begin VB.CommandButton cmdAddPatient 
         Caption         =   "Add Patient"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   960
         Style           =   1  'Graphical
         TabIndex        =   1
         Top             =   2760
         Width           =   1575
      End
      Begin VB.CommandButton cmdPrescription 
         Caption         =   "Administer Medicine"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   960
         Style           =   1  'Graphical
         TabIndex        =   2
         Top             =   3600
         Width           =   1575
      End
      Begin VB.CommandButton cmdRemovePatient 
         Caption         =   "Archive Patient Log"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   960
         Style           =   1  'Graphical
         TabIndex        =   4
         Top             =   5280
         Width           =   1575
      End
      Begin VB.CommandButton cmdLogout 
         Caption         =   "Logout"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   735
         Left            =   480
         TabIndex        =   0
         Top             =   1800
         Width           =   1575
      End
      Begin VB.Shape Shape2 
         Height          =   975
         Left            =   600
         Shape           =   2  'Oval
         Top             =   1560
         Width           =   1335
      End
      Begin VB.Shape Shape1 
         FillColor       =   &H8000000F&
         FillStyle       =   0  'Solid
         Height          =   615
         Left            =   960
         Shape           =   2  'Oval
         Top             =   960
         Width           =   615
      End
      Begin VB.Shape Shape12 
         BackColor       =   &H00800000&
         BorderColor     =   &H00800000&
         FillColor       =   &H00800000&
         FillStyle       =   0  'Solid
         Height          =   735
         Left            =   0
         Top             =   120
         Width           =   13335
      End
   End
   Begin VB.Shape Shape5 
      BackColor       =   &H00800000&
      BorderColor     =   &H00800000&
      FillColor       =   &H00800000&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   0
      Top             =   0
      Width           =   13335
   End
End
Attribute VB_Name = "frmUserDB"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'General
Option Explicit

Dim cn As ADODB.Connection
Dim rs As ADODB.Recordset
Dim SelectID As Long
Public OpenLog As Boolean
Dim trigger As CommandButton
Dim ReportType As String


Private Sub Command1_Click()

End Sub

Private Sub Command9_Click()
    Dim searchValue As String
    Dim lowerBound As Long
    Dim digits As Long
    Dim oldFilter As String
    
    searchValue = Trim(Text5.Text)

    If rs Is Nothing Then
        MsgBox "Record not loaded", vbInformation
        Exit Sub
    End If

    If searchValue = "" Then
        rs.Filter = ""
        Set DGData.DataSource = rs
        DGData.Refresh
        Exit Sub
    End If
    
    oldFilter = rs.Filter

    If IsNumeric(searchValue) Then
        lowerBound = CLng(searchValue)
        digits = Len(searchValue)
        
        rs.Filter = "ID >= " & lowerBound & " AND ID < " & (lowerBound + 1) * 10 ^ (Len(CStr(lowerBound)) - digits + 0)
    Else
        rs.Filter = "Name LIKE '%" & searchValue & "%'"
    End If
    
    If rs.EOF Then
        MsgBox "No record found!", vbInformation
        Exit Sub
    End If

    Set DGData.DataSource = rs
    DGData.Refresh
End Sub
'Main Logic
Private Sub Form_Load()
    fraAddPatient.Visible = False
    fraRemovePatient.Visible = False
    fraPrescription.Visible = False
    fraPatientLog.Visible = False
    Frame1.Visible = False
    cmdPConfirm.Enabled = False

    If OpenLog Then
        fraPatientLog.Visible = True
    Else
        fraMain.Visible = True
    End If

    Set cn = New ADODB.Connection
    cn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & App.Path & "\ClinicRecord.mdb"

    Set rs = New ADODB.Recordset
    rs.Open "SELECT * FROM patient_master", cn, adOpenDynamic, adLockOptimistic

    LoadCombo cboMedicine
    LoadSymptoms
    
    cboSex.Clear
    cboSex.AddItem "Male"
    cboSex.AddItem "Female"
    cboSex.ListIndex = 0

    dtpDOB.MaxDate = Date
    dtpDOB.MinDate = DateAdd("yyyy", -120, Date)
    
End Sub

'Helper Codes
Private Sub ShowRecord() 'Check and display records
    If rs Is Nothing Then Exit Sub
    If rs.EOF Or rs.BOF Then Exit Sub

    txtName.Text = rs!Name
    txtAge.Text = IIf(IsNull(rs!Age), "", rs!Age)
    If Not IsNull(rs!DOB) Then
        dtpDOB.Value = rs!DOB
    Else
        dtpDOB.Value = Date
    End If
    
    If Not IsNull(rs!Sex) Then
        If rs!Sex = "Male" Then
            cboSex.ListIndex = 0
        ElseIf rs!Sex = "Female" Then
            cboSex.ListIndex = 1
        Else
            cboSex.ListIndex = -1
        End If
    Else
        cboSex.ListIndex = -1
    End If
    
    txtAddress.Text = rs!Address
    txtSymptom.Text = rs!Symptom
    txtContact.Text = rs!Contact
    txtComplain.Text = rs!Complain
    txtTreatment.Text = IIf(IsNull(rs!Treatment), "", rs!Treatment)
    txtDiagnosis.Text = IIf(IsNull(rs!Diagnosis), "", rs!Diagnosis)
End Sub

Private Sub ShowFrame(fra As Frame)

    If fra.Visible Then
        fra.Visible = False
        Exit Sub
    End If
    
    fraAddPatient.Visible = False
    fraRemovePatient.Visible = False
    fraPatientLog.Visible = False
    fraPrescription.Visible = False
    Frame1.Visible = False
    fra.Visible = True

End Sub

Private Sub Clear() 'Clear filled inputs and assign default inputs
    txtName.Text = ""
    txtAge.Text = ""
    dtpDOB.Value = Date
    txtAddress.Text = ""
    cboSex.ListIndex = -1
    txtContact.Text = "09"
    txtComplain.Text = ""
    txtDiagnosis.Text = ""
    txtTreatment.Text = ""
    txtRID.Text = ""
    txtPID.Text = ""
    txtGivenMed = ""
    lblSelectedID.Caption = "Selected Patient: None"
    lblSelectedSymptom.Caption = "Patient Symptom: None"
    lblSelectedPatientRID.Caption = "Selected Patient: None"
    SelectID = 0
    cmdPConfirm.Enabled = False
End Sub

Public Sub LoadCombo(cbo As ComboBox) 'Loads combo boxes
    Set rs = New ADODB.Recordset

    If cn Is Nothing Then
        Set cn = New ADODB.Connection
        cn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & App.Path & "\ClinicRecord.mdb"
    End If

    rs.CursorLocation = adUseClient
    rs.Open "SELECT MedName FROM medicine_master ORDER BY MedName ASC", _
               cn, adOpenStatic, adLockReadOnly

    cbo.Clear
    Do While Not rs.EOF
        cbo.AddItem rs!MedName
        rs.MoveNext
    Loop
    
        cbo.ListIndex = -1

    rs.Close
    Set rs = Nothing
End Sub

Private Sub CalculateAge()

    If dtpDOB.Value > Date Then
        dtpDOB.Value = Date
        Exit Sub
    End If

    Dim Age As Integer
    Age = Year(Date) - Year(dtpDOB.Value)
    If Month(Date) < Month(dtpDOB.Value) _
    Or (Month(Date) = Month(dtpDOB.Value) And Day(Date) < Day(dtpDOB.Value)) Then
        Age = Age - 1
    End If
    
    If Age < 16 Or Age > 50 Then
        txtAge.Text = ""
        Exit Sub
    End If

    txtAge.Text = Age

End Sub

Private Sub LoadSymptoms()
    Dim rsSym As ADODB.Recordset
    Set rsSym = New ADODB.Recordset
    
    rsSym.Open "SELECT Symptom FROM symptom_master ORDER BY Symptom ASC", cn, adOpenStatic, adLockReadOnly
    
    txtSymptom.Clear
    
    Do Until rsSym.EOF
        txtSymptom.AddItem rsSym!Symptom
        rsSym.MoveNext
    Loop
    
    rsSym.Close
    Set rsSym = Nothing
End Sub

'Function Codes
Private Function Cleaner(ByVal txt As String) As String 'Get rid of Multi Spacing
    Dim result As String
    Dim i As Long
    Dim checker As String
    Dim lastSpace As Boolean
    
    For i = 1 To Len(txt)
        checker = Mid$(txt, i, 1)

        If checker = " " Then
            If Not lastSpace Then
                result = result & " "
                lastSpace = True
            End If
        Else
            result = result & checker
            lastSpace = False
        End If
    Next i
    
    Cleaner = result
End Function

Private Function GetNextID() As Long 'Display next unused IDs
    Set rs = New ADODB.Recordset

    rs.Open "SELECT MAX(ID) AS MaxID FROM patient_master", cn, adOpenForwardOnly, adLockReadOnly
    If rs.EOF Or IsNull(rs!MaxID) Then
        GetNextID = 1
    Else
        GetNextID = rs!MaxID + 1
    End If
    rs.Close
    Set rs = Nothing
End Function

Private Function CapitalizeName(ByVal s As String) As String 'Capitalizes names
    Dim result As String
    Dim i As Long
    Dim ch As String
    Dim capitalizeNext As Boolean
    
    result = ""
    capitalizeNext = True
    
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        
        If capitalizeNext And ch >= "a" And ch <= "z" Then
            ch = UCase$(ch)
            capitalizeNext = False
        ElseIf Not capitalizeNext And ch >= "A" And ch <= "Z" Then
            ch = LCase$(ch)
        ElseIf ch = " " Or ch = "-" Or ch = "'" Or ch = "." Then
            capitalizeNext = True
        Else
            capitalizeNext = False
        End If
        
        result = result & ch
    Next i
    
    CapitalizeName = result
End Function

'Add Patient Codes
Private Sub cmdAddPatient_Click()
    ShowFrame fraAddPatient
    Clear
    txtID.Text = GetNextID
    Highlight cmdAddPatient, fraAddPatient
End Sub

Private Sub dtpDOB_Change()
    CalculateAge
End Sub

Private Sub Text5_GotFocus()
    Command9.Default = True
    
End Sub

Private Sub txtContact_Change()
    Dim i As Integer
    Dim temp As String
    
    For i = 1 To Len(txtContact.Text)
        If Mid(txtContact.Text, i, 1) Like "[0-9]" Then
            temp = temp & Mid(txtContact.Text, i, 1)
        End If
    Next i
    
    If txtContact.Text <> temp Then
        txtContact.Text = temp
        txtContact.SelStart = Len(temp)
    End If

End Sub

Private Sub cmdAddConfirm_Click()
    Set rs = New ADODB.Recordset
    rs.Open "patient_master", cn, adOpenDynamic, adLockOptimistic

    'Cleaner
    txtName.Text = Cleaner(txtName.Text)
    txtAddress.Text = Cleaner(txtAddress.Text)
    txtComplain.Text = Cleaner(txtComplain.Text)
    
    If Trim(txtName.Text) = "" Then
        MsgBox "Please enter the Patient Name.", vbExclamation
        Exit Sub
    End If
    
    If Val(txtAge.Text) < 16 Or Val(txtAge.Text) > 50 Then
        MsgBox "Invalid Age.", vbExclamation
        Exit Sub
    End If
    
        If Trim(cboSex.Text) = "" Then
        MsgBox "Please enter the Patient Gender.", vbExclamation
        Exit Sub
    End If
    
        If Trim(txtAddress.Text) = "" Then
        MsgBox "Please enter the Patient Address.", vbExclamation
        Exit Sub
    End If
    

    If MsgBox("Are you sure you want to add this patient record?", vbYesNo + vbQuestion) = vbNo Then
        rs.CancelUpdate
        Exit Sub
    End If

    If txtContact.Text = "09" Then
        txtContact.Text = ""
    End If

    If txtContact.Text <> "" Then
        If Not txtContact.Text Like "09#########" Then
            MsgBox "Invalid Contact Details.", vbExclamation
            txtContact.SetFocus
            Exit Sub
        End If
    End If
    
    rs.AddNew
    rs!Name = CapitalizeName(Trim(txtName.Text))
    If IsNumeric(txtAge.Text) And Val(txtAge.Text) >= 0 Then rs!Age = CLng(txtAge.Text)
    rs!DOB = dtpDOB.Value
    rs!Address = Trim(txtAddress.Text)
    rs!Sex = cboSex.Text
    rs!Symptom = Trim(txtSymptom.Text)
    rs!Contact = Trim(txtContact.Text)
    rs!Complain = Trim(txtComplain.Text)

    rs.Update
    MsgBox "Patient record saved successfully!"
    rs.MoveLast
    ShowRecord
    txtID.Text = GetNextID
    Clear
End Sub

'Prescription Codes
Private Sub cmdPrescription_Click()
    ShowFrame fraPrescription
    Clear
    Highlight cmdPrescription, fraPrescription
End Sub

Private Sub cmdInv_Click()
    frmMedicineInventory.Show vbModal
End Sub

Private Sub cmdMedRefresh_Click()
    LoadCombo cboMedicine
    Clear
End Sub

Private Sub txtPID_Change()
    cmdPConfirm.Enabled = False

    If Trim(txtPID.Text) = "" Then
        lblSelectedID.Caption = "Selected Patient: None"
        lblSelectedSymptom.Caption = "Patient Symptom: None"
        Exit Sub
    End If

    If Not IsNumeric(txtPID.Text) Then
        lblSelectedID.Caption = ""
        lblSelectedSymptom.Caption = ""
        Exit Sub
    End If

    Dim patientID As Long
    patientID = CLng(txtPID.Text)

    Set rs = New ADODB.Recordset
    
    rs.Open "SELECT Name, Symptom, Medicine, Treatment, Diagnosis FROM patient_master WHERE ID = " & patientID, _
                cn, adOpenForwardOnly, adLockReadOnly

    If rs.EOF Then
        lblSelectedID.Caption = "No patient found"
        lblSelectedSymptom.Caption = "Patient Symptom: None"
        Exit Sub
    End If

    lblSelectedID.Caption = "Selected Patient: " & rs!Name
    lblSelectedSymptom.Caption = "Patient Symptom: " & rs!Symptom
    txtDiagnosis.Text = IIf(IsNull(rs!Diagnosis), "", rs!Diagnosis)
    txtTreatment.Text = IIf(IsNull(rs!Treatment), "", rs!Treatment)
    
    Dim medic As String
    medic = IIf(IsNull(rs!Medicine), "", rs!Medicine)

    If medic <> "" Then
        cboMedicine.ListIndex = cboMedicine.ListIndex
        cboMedicine.Text = medic
    End If
    

    If Not IsNull(rs!Medicine) Or _
       Not IsNull(rs!Treatment) Or _
       Not IsNull(rs!Diagnosis) Then
       
        lblSelectedID.Caption = lblSelectedID.Caption
        lblSelectedSymptom.Caption = lblSelectedSymptom.Caption
        MsgBox "Patient already has medication"
        cmdPConfirm.Enabled = False
        txtDiagnosis.Locked = True
        txtTreatment.Locked = True
        txtGivenMed.Locked = True
        cboMedicine.Locked = True
    Else
        cmdPConfirm.Enabled = True
        txtDiagnosis.Locked = False
        txtTreatment.Locked = False
        txtGivenMed.Locked = False
        cboMedicine.Locked = False
        SelectID = patientID
    End If

    rs.Close
    Set rs = Nothing

End Sub

Private Sub cmdPEdit_Click()
    frmEditData.OpenPrescription = True
    frmEditData.Show vbModal
End Sub

Private Sub cmdPConfirm_Click()
    'Cleaner
    txtTreatment.Text = Cleaner(txtTreatment.Text)
    txtDiagnosis.Text = Cleaner(txtDiagnosis.Text)
    
    If cboMedicine.Text = "" Then
        MsgBox "Please select a medicine.", vbExclamation
        Exit Sub
    End If

    If Trim(txtGivenMed.Text) = "" Or Not IsNumeric(txtGivenMed.Text) Then
        MsgBox "Please enter a valid quantity to give.", vbExclamation
        Exit Sub
    End If
    
    If Trim(txtDiagnosis.Text) = "" Then
        MsgBox "Please enter the completed diagnosis.", vbExclamation
        Exit Sub
    End If
    
    If Trim(txtTreatment.Text) = "" Then
        MsgBox "Please enter the Patient treatment plan.", vbExclamation
        Exit Sub
    End If

    Dim QtyToDeduct As Long
    QtyToDeduct = CLng(txtGivenMed.Text)

    If QtyToDeduct <= 0 Then
        MsgBox "Quantity must be greater than zero.", vbExclamation
        Exit Sub
    End If

    Set rs = New ADODB.Recordset
    rs.Open "SELECT * FROM medicine_master WHERE MedName='" & _
            Replace(cboMedicine.Text, "'", "''") & "'", _
            cn, adOpenDynamic, adLockOptimistic

    If rs.EOF Then
        MsgBox "Medicine not found.", vbCritical
        rs.Close
        Exit Sub
    End If

    If rs!StockQty < QtyToDeduct Then
        MsgBox "Not enough stock available!" & vbCrLf & _
               "Available: " & rs!StockQty, vbCritical
        rs.Close
        Exit Sub
    End If

    If MsgBox("Are you sure you want to save this patient's medication?", _
              vbYesNo + vbQuestion) = vbNo Then
        rs.Close
        Exit Sub
    End If

    rs!StockQty = rs!StockQty - QtyToDeduct
    rs.Update
    rs.Close

    Set rs = New ADODB.Recordset
    rs.Open "SELECT * FROM patient_master WHERE ID = " & _
            SelectID, cn, adOpenDynamic, adLockOptimistic

    If rs.EOF Then
        MsgBox "Patient record no longer exists.", vbCritical
        rs.Close
        Exit Sub
    End If

    rs!Medicine = cboMedicine.Text
    rs!Treatment = txtTreatment.Text
    rs!Diagnosis = txtDiagnosis.Text
    rs.Update

    rs.Close
    Set rs = Nothing

    MsgBox "Medication saved and stock updated successfully!", vbInformation

    ShowRecord
    Clear

End Sub

'Archive Codes
Private Sub cmdRemovePatient_Click()
    ShowFrame fraRemovePatient
    Set DGArchive.DataSource = Nothing
    Clear
    Highlight cmdRemovePatient, fraRemovePatient
End Sub

Private Sub txtRID_Change()
    If Trim(txtRID.Text) = "" Then
        lblSelectedPatientRID.Caption = "Selected Patient: None"
        Exit Sub
    End If

    If Not IsNumeric(txtRID.Text) Then
        lblSelectedPatientRID.Caption = ""
        Exit Sub
    End If

    Dim patientID As Long
    
    patientID = CLng(txtRID.Text)
    
    Set rs = New ADODB.Recordset
    rs.Open "SELECT Name FROM patient_master WHERE ID = " & patientID, _
                cn, adOpenForwardOnly, adLockReadOnly

    If rs.EOF Then
        lblSelectedPatientRID.Caption = "No patient found"
    Else
        lblSelectedPatientRID.Caption = "Selected Patient: " & rs!Name
    End If

    rs.Close
    Set rs = Nothing

End Sub

Private Sub cmdRConfirm_Click()
    Dim patientID As Long
    Dim Treatment As String, Diagnosis As String, Medicine As String
    Dim DOB As String, Age As String
    Dim Archive As String

    If Trim(txtRID.Text) = "" Or Not IsNumeric(txtRID.Text) Then
        MsgBox "Enter a valid Patient ID.", vbExclamation
        Exit Sub
    End If

    patientID = CLng(txtRID.Text)
    Set rs = New ADODB.Recordset
    rs.Open "SELECT * FROM patient_master WHERE ID=" & patientID, cn, adOpenDynamic, adLockOptimistic

    If rs.EOF Then
        MsgBox "No record found with that ID.", vbInformation
        rs.Close
        Set rs = Nothing
        Exit Sub
    End If

    If MsgBox("Are you sure you want to delete this record?", vbYesNo + vbQuestion) = vbNo Then
        rs.Close
        Set rs = Nothing
        Exit Sub
    End If

    If IsNull(rs!Treatment) Then
        Treatment = "NULL"
    Else
        Treatment = "'" & Replace$(rs!Treatment, "'", "''") & "'"
    End If

    If IsNull(rs!Diagnosis) Then
        Diagnosis = "NULL"
    Else
        Diagnosis = "'" & Replace$(rs!Diagnosis, "'", "''") & "'"
    End If

    If IsNull(rs!Medicine) Then
        Medicine = "NULL"
    Else
        Medicine = "'" & Replace$(rs!Medicine, "'", "''") & "'"
    End If

    If IsNull(rs!DOB) Then
        DOB = "NULL"
    Else
        DOB = "#" & Format$(rs!DOB, "mm/dd/yyyy") & "#"
    End If

    If IsNull(rs!Age) Then
        Age = "NULL"
    Else
        Age = rs!Age
    End If

    Archive = "INSERT INTO archive_master (ID, Name, Address, Age, DOB, Sex, Symptom, Contact, Complain, Treatment, Diagnosis, Medicine) VALUES (" & _
          rs!ID & ", '" & Replace(rs!Name, "'", "''") & "', '" & Replace(rs!Address, "'", "''") & "', " & _
          Age & ", " & DOB & ", '" & Replace(rs!Sex, "'", "''") & "', '" & Replace(rs!Symptom, "'", "''") & "', '" & _
          Replace(rs!Contact, "'", "''") & "', '" & Replace(rs!Complain, "'", "''") & "', " & _
          Treatment & ", " & Diagnosis & ", " & Medicine & ")"

    cn.Execute Archive
    rs.Delete
    rs.Close
    Set rs = Nothing

    MsgBox "Record archived and deleted successfully!"
    Clear
End Sub

Private Sub cmdLoadArchive_Click()
    Set cn = New ADODB.Connection
    cn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & App.Path & "\ClinicRecord.mdb"

    Set rs = New ADODB.Recordset
    rs.CursorLocation = adUseClient
    rs.Open "SELECT * FROM archive_master ORDER BY ID ASC", cn, adOpenStatic, adLockReadOnly

    Set DGArchive.DataSource = rs

    Dim col As Integer
    For col = 0 To 11
        DGArchive.Columns(col).Width = 1500
    Next col
End Sub

Private Sub cmdRefreshArchive_Click()
    If Not rs Is Nothing Then
        rs.Close
        Set rs = Nothing
    End If
    cmdLoadArchive_Click
End Sub

'Log Codes
Private Sub cmdReport_Click()
    ShowFrame Frame1
    Clear
    Highlight cmdReport, Frame1
End Sub

Private Sub cmdPatientLog_Click()
    ShowFrame fraPatientLog
    Set DGData.DataSource = Nothing
    Clear
    Highlight cmdPatientLog, fraPatientLog
End Sub

Private Sub cmdEdit_Click()
    Set rs = New ADODB.Recordset
    rs.Open "SELECT * FROM patient_master", cn, adOpenStatic, adLockReadOnly

    If rs.EOF Then
        MsgBox "No records found.", vbInformation
        rs.Close
        Set rs = Nothing
        Exit Sub
    End If

    frmEditData.OpenPrescription = False
    frmEditData.InitializeForm
    frmEditData.Show vbModal

    rs.Close
    Set rs = Nothing

End Sub

Private Sub cmdLoad_Click()
    Set rs = New ADODB.Recordset
    rs.CursorLocation = adUseClient
    rs.Open "SELECT * FROM patient_master ORDER BY ID ASC", cn, adOpenStatic, adLockReadOnly

    Set DGData.DataSource = rs

    Dim col As Integer
    For col = 0 To 11
        DGData.Columns(col).Width = 1500
    Next col
End Sub

Private Sub cmdRefresh_Click()
    If Not rs Is Nothing Then
        rs.Close
        Set rs = Nothing
    End If
    cmdLoad_Click
End Sub

'Logout Codes
Private Sub cmdLogout_Click()
        ResetAll
    If MsgBox("Are you sure you want to log out?", vbYesNo + vbQuestion) = vbYes Then
        Unload Me
        frmLogin.Show
        MsgBox "Successfully Logged Out!"
    End If
End Sub

'Key Ascii Codes
Private Sub NumOnly(KeyAscii As Integer)
    If KeyAscii = vbKeyBack Then Exit Sub
        If KeyAscii < 48 Or KeyAscii > 57 Then
            KeyAscii = 0
        End If

End Sub

Private Sub FilterInput(KeyAscii As Integer, _
                        ByVal AllowNumbers As Boolean, _
                        ByVal AllowExtraChars As String)

    If KeyAscii = vbKeyBack Then Exit Sub

    If (KeyAscii >= 65 And KeyAscii <= 90) Or _
       (KeyAscii >= 97 And KeyAscii <= 122) Or _
       (KeyAscii = 164 Or KeyAscii = 165) Then Exit Sub
       
    If AllowNumbers Then
        If KeyAscii >= 48 And KeyAscii <= 57 Then Exit Sub
    End If

    If InStr(AllowExtraChars, Chr(KeyAscii)) > 0 Then Exit Sub
    
    KeyAscii = 0

End Sub

Private Sub txtContact_KeyPress(KeyAscii As Integer)
    If txtContact.SelStart < 3 And KeyAscii = vbKeyBack Then
        KeyAscii = 0
    End If
    
End Sub

Private Sub txtPID_KeyPress(KeyAscii As Integer)
    NumOnly KeyAscii
End Sub

Private Sub txtRID_Keypress(KeyAscii As Integer)
    NumOnly KeyAscii
End Sub

Private Sub txtName_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, False, " .-'"
End Sub

Private Sub txtAddress_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, True, " ,.-#'"
End Sub

Private Sub txtCondition_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, False, " ,.-()"
End Sub

Private Sub txtSymptom_GotFocus()
    cmdAddSymptom.Default = True
End Sub

Private Sub txtSymptom_LostFocus()
    cmdAddSymptom.Default = False
    cmdAddConfirm.Default = True
End Sub

Private Sub txtSymptom_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, False, ""
End Sub

Private Sub txtComplain_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, True, " ,.-#'()"
End Sub

Private Sub txtDiagnosis_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, True, " ,.-#'()"
End Sub

Private Sub txtTreatment_KeyPress(KeyAscii As Integer)
    FilterInput KeyAscii, True, " ,.-#'()"
End Sub

Private Sub txtName_Validate(Cancel As Boolean)
    If txtName.Text = "" Then Exit Sub
    If txtName.Text Like "*[!A-Za-z�� .'-]*" Then
        MsgBox "Invalid characters in Name.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtSymptom_Validate(Cancel As Boolean)
    If txtName.Text = "" Then Exit Sub
    If txtName.Text Like "*[!A-Za-z��]*" Then
        MsgBox "Invalid characters in Symptom.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtAddress_Validate(Cancel As Boolean)
    If txtAddress.Text = "" Then Exit Sub
    If txtAddress.Text Like "*[!A-Za-z0-9 ,.\#'-]*" Then
        MsgBox "Invalid characters.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtComplain_Validate(Cancel As Boolean)
    If txtComplain.Text = "" Then Exit Sub
    If txtComplain.Text Like "*[!A-Za-z0-9 ,.\#'()-]*" Then
        MsgBox "Invalid characters.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtDiagnosis_Validate(Cancel As Boolean)
    If txtDiagnosis.Text = "" Then Exit Sub
    If txtDiagnosis.Text Like "*[!A-Za-z0-9 ,.\#'()-]*" Then
        MsgBox "Invalid characters.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtTreatment_Validate(Cancel As Boolean)
    If txtTreatment.Text = "" Then Exit Sub
    If txtTreatment.Text Like "*[!A-Za-z0-9 ,.\#'()-]*" Then
        MsgBox "Invalid characters.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtPID_Validate(Cancel As Boolean)
    If txtID.Text <> "" And Not IsNumeric(txtID.Text) Then
        MsgBox "Numbers only.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtRID_Validate(Cancel As Boolean)
    If txtID.Text <> "" And Not IsNumeric(txtID.Text) Then
        MsgBox "Numbers only.", vbExclamation
        Cancel = True
    End If
End Sub

Private Sub txtGivenMed_KeyPress(KeyAscii As Integer)
    If Not (KeyAscii >= 48 And KeyAscii <= 57) And KeyAscii <> 8 Then
        KeyAscii = 0
    End If

End Sub

Private Sub DTPicker1_KeyPress(KeyAscii As Integer)
    KeyAscii = 0
    
End Sub

Private Sub dtpDOB_GotFocus()
    txtDOB.SetFocus
End Sub

Private Sub Highlight(cmd As CommandButton, fra As Frame)
    If trigger Is cmd Then
        cmd.BackColor = vbButtonFace
        Set trigger = Nothing
        Exit Sub
    End If
    
    If Not trigger Is Nothing Then
        trigger.BackColor = vbButtonFace
    End If
    
    cmd.BackColor = fra.BackColor
    Set trigger = cmd

End Sub

Private Sub ResetAll()
    If Not trigger Is Nothing Then
        trigger.BackColor = vbButtonFace
        Set trigger = Nothing
        Exit Sub
    End If
End Sub

'Record Load Codes
Private Sub cmdLog_Click()
    ReportType = "LOG"
    If Not rs Is Nothing Then
        If rs.State = adStateOpen Then rs.Close
    End If

    Set rs = New ADODB.Recordset
    rs.CursorLocation = adUseClient


    rs.Open "SELECT ID, Name, Complain, Diagnosis, Treatment, Medicine " & _
                  "FROM patient_master ORDER BY ID ASC", _
                  cn, adOpenStatic, adLockReadOnly

    If rs.EOF Then
        MsgBox "No records found.", vbInformation
        Exit Sub
    End If

    Set DGReport.DataSource = rs
    MsgBox "Daily Consultation Log Loaded.", vbInformation
    
End Sub

Private Sub cmdInventory_Click()
    ReportType = "INVENTORY"
    If Not rs Is Nothing Then
        If rs.State = adStateOpen Then rs.Close
    End If

    Set rs = New ADODB.Recordset
    rs.CursorLocation = adUseClient

    rs.Open "SELECT MedID, MedName, Manufacturer, StockQty, " & _
                  "IIF(StockQty <= 10, 'LOW', 'OK') AS AlertStatus " & _
                  "FROM medicine_master ORDER BY MedName ASC", _
                  cn, adOpenStatic, adLockReadOnly

    If rs.EOF Then
        MsgBox "No inventory records found.", vbInformation
        Exit Sub
    End If

    Set DGReport.DataSource = rs
    MsgBox "Inventory Report Loaded.", vbInformation

End Sub

Private Sub cmdLowStock_Click()
    ReportType = "LOWSTOCK"
    If Not rs Is Nothing Then
        If rs.State = adStateOpen Then rs.Close
    End If

    Set rs = New ADODB.Recordset
    rs.CursorLocation = adUseClient

    rs.Open "SELECT MedID, MedName, Manufacturer, StockQty, " & _
                  "IIF(StockQty <= 10, 'LOW', 'OK') AS AlertStatus " & _
                  "FROM medicine_master " & _
                  "WHERE StockQty <= 10 " & _
                  "ORDER BY StockQty ASC", _
                  cn, adOpenStatic, adLockReadOnly

    If rs.EOF Then
        MsgBox "No low stock medicines.", vbInformation
        Exit Sub
    End If

    Set DGReport.DataSource = rs
    MsgBox "Low Stock Report Loaded.", vbInformation

End Sub

'Print Codes
Private Sub cmdMedicalCert_Click()
    On Error GoTo PrintError
    Dim PID As String

    frmInputPID.PIDValue = ""
    frmInputPID.Show vbModal

    PID = frmInputPID.PIDValue
    Unload frmInputPID

    If PID = "" Then Exit Sub

    Dim rsCert As New ADODB.Recordset
    rsCert.Open "SELECT Name, Diagnosis FROM patient_master WHERE ID = " & PID, _
                cn, adOpenStatic, adLockReadOnly

    If rsCert.EOF Then
        MsgBox "Patient not found.", vbCritical
        rsCert.Close
        Exit Sub
    End If

    Printer.FontSize = 14
    Printer.FontBold = True
    Printer.Print "                 MEDICAL CERTIFICATE"
    Printer.Print ""
    Printer.FontBold = False
    Printer.FontSize = 10
    Printer.Print "This is to certify that " & rsCert!Name & _
                  " was examined on " & Format(Date, "mmmm dd, yyyy") & "."
    Printer.Print ""
    Printer.Print "Diagnosis: " & rsCert!Diagnosis
    Printer.Print ""
    Printer.Print "He/She is advised to take proper medication and rest."
    Printer.Print ""
    Printer.Print ""
    Printer.Print "Physician Signature: ___________________________"
    Printer.EndDoc
    
    MsgBox "Medical Certificate Printed Successfully!", vbInformation
    rsCert.Close
    Set rsCert = Nothing
    Exit Sub
    
PrintError:
    If Err.Number = 482 Then
        MsgBox "Printing canceled by user.", vbInformation
    Else
        MsgBox "Printer error: " & Err.Description, vbCritical
    End If
    Err.Clear
End Sub

Private Sub PrintMultiLine(ByVal TextValue As String, ByVal LeftMargin As Integer)

    Dim Words() As String
    Dim LineText As String
    Dim i As Integer
    Dim MaxWidth As Single

    MaxWidth = Printer.ScaleWidth - LeftMargin - 500

    Words = Split(TextValue, " ")

    LineText = ""

    For i = 0 To UBound(Words)

        If Printer.TextWidth(LineText & Words(i) & " ") > MaxWidth Then
            Printer.CurrentX = LeftMargin
            Printer.Print LineText
            LineText = Words(i) & " "
        Else
            LineText = LineText & Words(i) & " "
        End If

    Next i

    If LineText <> "" Then
        Printer.CurrentX = LeftMargin
        Printer.Print LineText
    End If

End Sub

Private Sub PrintSection(ByVal Title As String, ByVal TextValue As String)

    Printer.FontBold = True
    Printer.Print Title
    Printer.FontBold = False

    Call PrintWrappedText(TextValue, 600)

    Printer.Print ""

End Sub
Private Sub PrintWrappedText(ByVal TextValue As String, ByVal LeftMargin As Integer)

    Dim MaxWidth As Single
    Dim CurrentLine As String
    Dim i As Integer
    Dim c As String
    Dim TempLine As String

    MaxWidth = Printer.ScaleWidth - LeftMargin - 400

    CurrentLine = ""

    For i = 1 To Len(TextValue)
        c = Mid(TextValue, i, 1)
        TempLine = CurrentLine & c

        If Printer.TextWidth(TempLine) > MaxWidth Then
            ' Print current line and start a new one
            Printer.CurrentX = LeftMargin
            Printer.Print CurrentLine
            CurrentLine = c ' start new line with current char
        Else
            CurrentLine = TempLine
        End If
    Next i

    ' Print any remaining text
    If CurrentLine <> "" Then
        Printer.CurrentX = LeftMargin
        Printer.Print CurrentLine
    End If

End Sub
Private Sub cmdPrint_Click()

    On Error GoTo PrintError

    If rs Is Nothing Then
        MsgBox "No report loaded.", vbExclamation
        Exit Sub
    End If

    If rs.State <> adStateOpen Then
        MsgBox "Report not available.", vbExclamation
        Exit Sub
    End If

    If Printers.Count = 0 Then
        MsgBox "No printer installed.", vbCritical
        Exit Sub
    End If

    Printer.FontName = "Courier New"
    Printer.FontSize = 10

    If ReportType = "LOG" Then

        frmInputPID.PIDValue = ""
        frmInputPID.Show vbModal

        If frmInputPID.PIDValue = "" Then
            MsgBox "Printing cancelled.", vbInformation
            Exit Sub
        End If

        Dim rsPrint As ADODB.Recordset
        Set rsPrint = New ADODB.Recordset

        rsPrint.Open "SELECT ID, Name, Complain, Diagnosis, Treatment, Medicine " & _
                     "FROM patient_master WHERE ID = " & frmInputPID.PIDValue, _
                     cn, adOpenStatic, adLockReadOnly

        If rsPrint.EOF Then
            MsgBox "No consultation record found.", vbExclamation
            rsPrint.Close
            Exit Sub
        End If

        Printer.FontSize = 14
        Printer.FontBold = True
        Printer.Print "CLINIC CONSULTATION RECORD"
        Printer.FontBold = False
        Printer.Print String(60, "-")

        Printer.FontSize = 10
        Printer.Print "Date Printed : " & Format(Now, "mmmm dd, yyyy hh:mm AM/PM")
        Printer.Print ""

        Printer.Print "Patient ID   : " & rsPrint!ID
        Printer.Print "Patient Name : " & rsPrint!Name

        Printer.Print ""
        Printer.Print String(60, "-")
        Printer.Print ""

        Call PrintSection("Patient Explanation:", rsPrint!Complain)
        Call PrintSection("Diagnosis:", rsPrint!Diagnosis)
        Call PrintSection("Treatment:", rsPrint!Treatment)
        Call PrintSection("Medicine Given:", rsPrint!Medicine)

        Printer.Print ""
        Printer.Print "____________________________"
        Printer.Print "Attending Nurse"

        rsPrint.Close
        Set rsPrint = Nothing


    '========================================
    ' INVENTORY & LOW STOCK PRINT
    '========================================
    Else

        Printer.FontSize = 14
        Printer.FontBold = True

        If ReportType = "LOWSTOCK" Then
            Printer.Print "LOW STOCK MEDICINE REPORT"
        Else
            Printer.Print "MEDICINE INVENTORY REPORT"
        End If

        Printer.FontBold = False
        Printer.Print "Generated: " & Format(Now, "mmmm dd, yyyy hh:mm AM/PM")
        Printer.Print String(70, "-")

        Printer.Print ""
        Printer.FontBold = True
        Printer.Print "ID"; Tab(6); "MEDICINE"; Tab(28); "MANUFACTURER"; Tab(55); "QTY"; Tab(63); "STATUS"
        Printer.FontBold = False
        Printer.Print String(70, "-")

        rs.MoveFirst

        Do While Not rs.EOF

            Printer.Print _
                rs!MedID; _
                Tab(6); rs!MedName; _
                Tab(28); rs!Manufacturer; _
                Tab(55); rs!StockQty; _
                Tab(63); rs!AlertStatus

            rs.MoveNext

        Loop

        Printer.Print String(70, "-")
        Printer.Print ""
        Printer.Print "End of Report"

    End If

    Printer.EndDoc

    MsgBox "Printing successful.", vbInformation
    Exit Sub


PrintError:

    If Err.Number = 482 Then
        MsgBox "Printing canceled by user.", vbInformation
    Else
        MsgBox "Printer error: " & Err.Description, vbCritical
    End If

    Err.Clear

End Sub
Private Sub cmdExportPDF_Click()
    If rs Is Nothing Then
        MsgBox "No report loaded.", vbExclamation
        Exit Sub
    End If

    If rs.State <> adStateOpen Then
        MsgBox "Report not available.", vbExclamation
        Exit Sub
    End If

    If rs.EOF Then
        MsgBox "Report is empty.", vbExclamation
        Exit Sub
    End If

    Dim prt As Printer
    Dim found As Boolean
    found = False

    For Each prt In Printers
        If prt.DeviceName = "Microsoft Print to PDF" Then
            Set Printer = prt
            found = True
            Exit For
        End If
    Next

    If Not found Then
        MsgBox "Microsoft Print to PDF not found.", vbCritical
        Exit Sub
    End If

    Printer.ScaleMode = vbTwips
    Printer.CurrentX = 1000
    Printer.CurrentY = 1000

    rs.MoveFirst
    Printer.FontSize = 12
    Printer.FontBold = True
    Printer.Print "CLINIC REPORT"
    Printer.FontBold = False
    Printer.Print "Generated: " & Format(Now, "mmmm dd, yyyy hh:mm AM/PM")
    Printer.Print String(100, "-")
    Printer.Print ""

    Dim field As Integer
    Dim rowText As String
    
    Do While Not rs.EOF

        rowText = ""

        For field = 0 To rs.Fields.Count - 1
            If IsNull(rs.Fields(field).Value) Then
                rowText = rowText & ""
            Else
                rowText = rowText & rs.Fields(field).Value
            End If

            rowText = rowText & "    "
        Next field

        Printer.Print rowText
        If Printer.CurrentY > Printer.ScaleHeight - 1000 Then
            Printer.NewPage
            Printer.CurrentX = 1000
            Printer.CurrentY = 1000
        End If

        rs.MoveNext
    Loop

    Printer.EndDoc

    MsgBox "PDF file generated. Please choose save location.", vbInformation

End Sub

Private Sub cmdAddSymptom_Click()
    Dim rsSym As ADODB.Recordset
    Dim NewData As String
    Dim exists As Boolean
    Dim result As VbMsgBoxResult

    NewData = Trim(txtSymptom.Text)
    If NewData = "" Then
        MsgBox "Please enter a symptom.", vbExclamation
        Exit Sub
    End If

    exists = False
    Set rsSym = New ADODB.Recordset
    rsSym.Open "SELECT Symptom FROM symptom_master WHERE Symptom='" & Replace(NewData, "'", "''") & "'", _
               cn, adOpenStatic, adLockReadOnly
    If Not rsSym.EOF Then
        exists = True
    End If
    rsSym.Close
    Set rsSym = Nothing

    If Not exists Then
        result = MsgBox("Symptom '" & NewData & "' is not in the list. Do you want to add it?", vbYesNo + vbQuestion)
        If result = vbYes Then
            Set rsSym = New ADODB.Recordset
            rsSym.Open "symptom_master", cn, adOpenDynamic, adLockOptimistic
            rsSym.AddNew
            rsSym!Symptom = NewData
            rsSym.Update
            rsSym.Close
            Set rsSym = Nothing

            LoadSymptoms
            txtSymptom.Text = NewData
            MsgBox "Symptom added successfully!", vbInformation
        Else
            txtSymptom.Text = ""
        End If
    Else
        MsgBox "Symptom '" & NewData & "' already exists in the list.", vbInformation
    End If
End Sub
